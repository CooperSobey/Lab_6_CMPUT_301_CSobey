package com.example.listycity;

public class City implements Comparable{
    private String city;
    private String province;

    /**
     * City object
     * @param city
     * @param province
     */
    public City(String city, String province){
        this.city = city;
        this.province = province;
    }

    /**
     * Getter for city name
     * @return
     * city string
     */
    public String getCity() {
        return city;
    }


    /**
     * Setter for city name
     * @param city
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Getter for province name
     * @return
     * return province string
     */
    public String getProvince() {
        return province;
    }


    /**
     * Setter for province name
     * @param province
     */
    public void setProvince(String province) {
        this.province = province;
    }

    @Override
    /** This method compares cities based on city name field
     * @return -1 if the caller is greater than the name of the city name field of called object
     */
    public int compareTo(Object o){
        City city = (City) o; //Typecasting
        return this.city.compareTo(city.getCity());
    }

    /**
     * This method is an overridden equals method that checks if the objects are identical, not if they have the same pointer
     * @param o
     * @return
     * true if equal
     * false if not in the list
     */
    @Override
    public boolean equals (Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        City city1 = (City) o;
        return city.equals(city1.city) && province.equals(city1.province);
    }


    /**
     * Overridden hashCode block to return city and province hashCode rather than just the objects
     * @return
     * city and province hashCode
     */
    @Override
    public int hashCode() {
        return city.hashCode() + province.hashCode();
    }


}

